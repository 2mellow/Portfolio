/**
 * Project 3: Sunflower
 * The main class that creates a sunflower and draws it
 *
 * @author      Markell Thornton
 * @version     1.0
 * @date        7/22/2023
 */
public class Main {
    public static void main(String[] args) {
        Sunflower sunflower = new Sunflower(400, 100, 9);
        sunflower.draw();
    }

}
