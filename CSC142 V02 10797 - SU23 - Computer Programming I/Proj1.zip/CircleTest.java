import org.junit.jupiter.api.Test;

import java.awt.Color;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;


/**
 * Project 3: Sunflower
 * A class to test the functionality of circle class
 *
 * @author Markell Thornton
 * @version 1.0
 * @date 7/22/2023
 */
public class CircleTest {

    @Test
    public void testConstructor() {
        Circle circle = new Circle(new Color(100, 120, 80), 50.0, 30.4, 100);
        assertEquals(circle.getRadius(), 100);
    }

    @Test
    public void testSetColor() {
        Circle circle = new Circle(new Color(100, 120, 80), 50.0, 30.4, 100);
        assertEquals(new Color(100, 120, 80), circle.getColor());
    }

    @Test
    public void testSetCenterX() {
        Circle circle = new Circle(new Color(100, 120, 80), 50.0, 30.4, 100);
        assertEquals(50.0, circle.getCenterX());
    }

    @Test
    public void testSetCenterY() {
        Circle circle = new Circle(new Color(100, 120, 80), 50.0, 30.4, 100);
        assertEquals(30.4, circle.getCenterY());
    }

    @Test
    public void testSetRadius() {
        Circle circle = new Circle(new Color(100, 120, 80), 50.0, 30.4, 100);
        assertEquals(100, circle.getRadius());
    }

    @Test
    public void testSetNegativeRadius() {
        Circle circle = new Circle(new Color(100, 120, 80), 50.0, 30.4, 50);
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            circle.setRadius(-20.5);
        }, "Setting negative radius should throw");
        assertEquals("radius is negative", thrown.getMessage());
    }

    @Test
    public void testSetNullColor() {
        Circle circle = new Circle(new Color(100, 120, 80), 50.0, 30.4, 50);
        Color color = null;
        IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            circle.setColor(color);
        }, "Setting null color should throw");
        assertEquals("color is null", thrown.getMessage());
    }

}