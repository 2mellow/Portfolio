import java.awt.Graphics;
import java.awt.Color;

/**
 * Project 3: Sunflower
 * A class that draws a circle of a given color, center and radius on a panel
 * 
 * @author      Markell Thornton
 * @version     1.0
 * @date        7/22/2023
 */
public class Circle {
    private Color color;
    private double centerX;
    private double centerY;
    private double radius;
    
    /**
     * Creates a circle with given parameters
     *
     * @param color
     * @param centerX
     * @param centerY
     * @param radius
     * @return x coordinate of the centre of the circle.
     */
    public Circle(Color color, double centerX, double centerY, double radius) {
        setColor(color);
        setCenterX(centerX);
        setCenterY(centerY);
        setRadius(radius);
    }

    // Accessors

    /**
     * This method returns the color of the circle
     *
     * @return Color.
     */
    public Color getColor() {
        return color;
    }

    /**
     * This method returns the x coordinate of the centre of the circle.
     *
     * @return x coordinate of the centre of the circle.
     */
    public double getCenterX() {
        return centerX;
    }

    /**
     * This method returns the y coordinate of the centre of the circle.
     *
     * @return y coordinate of the centre of the circle.
     */
    public double getCenterY() {
        return centerY;
    }

    /**
     * This method returns the radius of the circle.
     *
     * @return radius of the circle.
     */
    public double getRadius() {
        return radius;
    }

    // Mutators

    /**
     * This method sets the color of the circle.
     *
     * @param color new color
     * @throws IllegalArgumentException if color isnull
     */
    public void setColor(Color color) {
        if (color == null) {
            throw new IllegalArgumentException("color is null");
        }
        this.color = color;
    }

    /**
     * This method sets the x coordinate of the centre of the circle.
     *
     * @param centerX the new centerX
     */
    public void setCenterX(double centerX) {
        this.centerX = centerX;
    }

    /**
     * This method sets the Y coordinate of the centre of the circle.
     *
     * @param centerY the new centerY
     */
    public void setCenterY(double centerY) {
        this.centerY = centerY;
    }

    /**
     * This method sets the radius of the circle.
     *
     * @param radius the new radius
     * @throws IllegalArgumentException if radius < 0
     */
    public void setRadius(double radius) {
        if (radius < 0) {
            throw new IllegalArgumentException("radius is negative");
        }
        this.radius = radius;
    }

    /**
     * This method draws the circle on panel.
     *
     * @param graphics drawing graphics
     * @param drawSize size of panel
     * @throws IllegalArgumentException if drawSize < 1
     */
    public void draw(Graphics graphics, int drawSize) {
        if (drawSize < 1) {
            throw new IllegalArgumentException("Draw size cannot be less than 1 pixel");
        }
        graphics.setColor(color);
        int upperLeftX = (int)cartesianXToGraphicX(drawSize, centerX - radius);
        int upperLeftY = (int)cartesianYToGraphicY(drawSize, centerY + radius);
        graphics.fillOval(upperLeftX, upperLeftY, (int)radius * 2,(int)radius * 2);
    }

    /**
     * This method gives the string representation of the circle
     *
     * @return String containing circle coordinates radius and color.
     */
    public String toString() {
        return String.format("Circle centered at (%.4f, %.4f) with radius %.4f and color %s", centerX,
                centerY, radius, color.toString());
    }

    /**
     * This method converts cartesian x coordinate to graphic coordinate
     *
     * @param drawWidth
     * @param x
     * @return x graphic coordinate
     */
    private static double cartesianXToGraphicX(int drawWidth, double x) {
        return x + drawWidth / 2;
    }

    /**
     * This method converts cartesian y coordinate to graphic coordinate
     *
     * @param drawHeight
     * @param y
     * @return y graphic coordinates
     */
    private static double cartesianYToGraphicY(int drawHeight, double y) {
        return drawHeight / 2 - y;
    }
    
}