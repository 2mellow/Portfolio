import java.awt.Color;
import java.awt.Graphics;
import java.lang.Thread;

/**
 * Project 3: Sunflower
 * A class that draws a sunflower of a given color, no of petals and size on a panel.
 *
 * @author      Markell Thornton
 * @version     1.0
 * @date        7/22/2023
 */
public class Sunflower {
    private final Color COLOR_CENTER = new Color(97, 54, 23);
    private final Color COLOR_PETALS = new Color(252, 206, 1);
    private final Color COLOR_BACKGROUND_TOP = new Color(218, 227, 243);
    private final Color COLOR_BACKGROUND_BOTTOM = new Color(143, 170, 220);
    private int drawingSize;
    private int centerRadius;
    private int petalCount;

    // Constructor
    public Sunflower(int drawingSize, int centerRadius, int petalCount) {
        this.drawingSize = drawingSize;
        this.centerRadius = centerRadius;
        this.petalCount = petalCount;
    }

    // Calculates the position of each circle and instantiates circles
    public void draw() {
        DrawingPanel panel = new DrawingPanel(drawingSize, drawingSize);
        // panel.setBackground(new Color(143, 170, 220));
        Graphics graphics = panel.getGraphics();
        drawGradientBackground(graphics);

        double centerX = 0.0;
        double centerY = 0.0;
        double radius = centerRadius * 1.0;
        Circle circle = new Circle(COLOR_CENTER, centerX, centerY, radius);
        circle.draw(graphics, drawingSize);

        double angle = (2 * Math.PI) / petalCount;
        double distBetweenCenters = 1.5 * centerRadius;

        for (int i = 0; i < petalCount; i++) {
            double x = centerX + distBetweenCenters * Math.cos(angle * i);
            double y = centerY + distBetweenCenters * Math.sin(angle * i);
            Circle petal = new Circle(COLOR_PETALS, x, y, radius / 2);
            petal.draw(graphics, drawingSize);
            sleepHalfSecond();
        }
    }

    // Pauses for half after a circle finishes drawing
    private void sleepHalfSecond() {
        try {
            Thread.sleep(500);
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
    }

    /*
     * Draws the gradient background of the panel
     */
    private void drawGradientBackground(Graphics graphics) {
        double R1 = COLOR_BACKGROUND_TOP.getRed();
        double G1 = COLOR_BACKGROUND_TOP.getGreen();
        double B1 = COLOR_BACKGROUND_TOP.getBlue();
        double R2 = COLOR_BACKGROUND_BOTTOM.getRed();
        double G2 = COLOR_BACKGROUND_BOTTOM.getGreen();
        double B2 = COLOR_BACKGROUND_BOTTOM.getBlue();

        double er = Math.max(R1, R2);
        double eg = Math.max(G1, G2);
        double eb = Math.max(B1, B2);

        for (int i = 0; i < drawingSize; i++) {
            double ratio = (i * 1.0) / drawingSize;
            double r = er - (R1 - R2) * ratio;
            double g = eg - (G1 - G2) * ratio;
            double b = eb - (B1 - B2) * ratio;
            int x1 = 0;
            int y1 = i;
            int x2 = drawingSize;
            int y2 = i;
            Color color = new Color((int) r, (int) g, (int) b);
            graphics.setColor(color);
            graphics.drawLine(x1, y1, x2, y2);
        }
    }

}