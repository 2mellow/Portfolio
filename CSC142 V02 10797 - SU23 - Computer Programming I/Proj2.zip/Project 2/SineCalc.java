/**
 * A class with sine calculation functions
 *
 * @author      Markell Thornton
 * @version     1.0
 * @date        7/14/2023
 */


/**
 * contains methods that use sine
 */
public class SineCalc {

    /**
     *  Calculates the area under a curve using Midpoint Riemann Sum
     */
    public static double estimateArea(int no) {
        // negative no not allowed
        if (no <= 0) {
            throw new IllegalArgumentException("no can not be less than 0");
        }

        double width = Math.PI / no;
        double area = 0;
        for (double i = 0; i < Math.PI; i += width) {
            double end = i + width;
            double mid = (end + i) / 2;
            double y = Math.sin(mid);
            double recArea = y * width;
            area += recArea;
        }
        return area;
    }

    /**
     * Calculate the sine of the provided x
     */
    public static double findY(double x) {
        return Math.sin(x);
    }
}
