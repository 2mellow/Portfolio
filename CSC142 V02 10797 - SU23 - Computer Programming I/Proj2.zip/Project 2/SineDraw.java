/**
 * A class with sine calculation functions
 *
 * @author      Markell Thornton
 * @version     1.0
 * @date        7/14/2023
 */

import java.awt.*;

/**
 * Draws a sine wave and also area estimation rectangles
 */
public class SineDraw {
    private static final int HEIGHT = 200;
    private static final int WIDTH = 628;

    /**
     * Convert cartesian x coordinate to drawing x coordinate
     */
    private static int cartesianXToGraphicX(double x) {
        double scaledX = (x / Math.PI) * WIDTH;
        return (int) scaledX;
    }

    /**
     * Convert cartesian x coordinate to drawing x coordinate
     */
    private static int cartesianYToGraphicY(double y) {
        double scaledY = y * (HEIGHT); // -5 to get a padding on top for curve
        return (int) (HEIGHT - scaledY);
    }

    /**
     * Draws a sine wave with the supplied number(no) of area estimation rectangles
     */
    public static void drawSineWave(int no) {
        DrawingPanel drawingPanel = new DrawingPanel(WIDTH, HEIGHT);
        drawingPanel.setBackground(Color.WHITE);
        Graphics graphics = drawingPanel.getGraphics();

        // draw the rectangles
        double recWidth = Math.PI / no;
        for (int i = 0; i < no; i++) {
            double start = recWidth * i;
            double end = recWidth * (i + 1);
            double mid = (start + end) / 2;
            double y = Math.sin(mid);
            double x = start;
            graphics.setColor(Color.red);
            graphics.drawRect(
                    cartesianXToGraphicX(x),
                    cartesianYToGraphicY(y),
                    (int) (recWidth / Math.PI * WIDTH),
                    (int) (y * HEIGHT)
            );
        }

        // draw the sine curve
        double width = 0.001;
        for (double i = 0; i < Math.PI; i += width) {
            double x1 = i;
            double y1 = Math.sin(i);
            double lineEnd = i + width;
            double x2 = lineEnd;
            double y2 = Math.sin(lineEnd);
            graphics.setColor(Color.BLUE);
            graphics.drawLine(
                    cartesianXToGraphicX(x1),
                    cartesianYToGraphicY(y1),
                    cartesianXToGraphicX(x2),
                    cartesianYToGraphicY(y2)
            );
        }
    }

}
