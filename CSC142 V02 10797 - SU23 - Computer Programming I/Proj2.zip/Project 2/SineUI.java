/**
 * A class with sine calculation functions
 *
 * @author Markell Thornton
 * @version 1.0
 * @date 7/14/2023
 */

import java.util.Scanner;

public class SineUI {

    /**
     * Asks the user for a number in range of min to max, throws exception if supplied min > max
     */
    public static int chooseInRange(int min, int max) {
        if (min > max) {
            throw new IllegalArgumentException("Min values is larger than max value");
        }
        Scanner scanner = new Scanner(System.in);
        int no = 0;
        boolean done = false;
        while (!done) {
            if (scanner.hasNextInt()) {
                no = scanner.nextInt();
                if (no >= min && no <= max) {
                    done = true;
                } else {
                    System.out.println("Number not in range of " + min + "-" + max);
                }
            } else {
                System.out.println("Enter only numbers");
                scanner.next();
            }
        }
        // scanner.close();
        return no;
    }

    /**
     * Prints the program menu and prompt user for next action.
     */
    public static void printMenu() {
        System.out.println("""
                ---------------------------------------------
                Sine Wave Menu
                ---------------------------------------------
                                
                1.  Find y value for specified radians x
                2.  Estimate area for O <= x <= PI
                3.  Draw curve with area estimation rectangles
                                
                0.  EXIT the program
                                
                Enter your choice: """);
    }

    /**
     * Asks a user for an x in radians and calculates its Y value from the sine wave
     */
    public static void findYChoice() {
        System.out.print("Enter x in radians: ");
        double x = 0;
        boolean done = false;
        Scanner scanner = new Scanner(System.in);
        while (!done) {
            if (scanner.hasNextDouble()) {
                x = scanner.nextDouble();
                done = true;
            } else {
                System.out.println("Enter a number");
            }
        }
        // scanner.close();
        double y = SineCalc.findY(x);
        System.out.printf("y = %.4f\n", y);
    }

    /**
     * Asks a user for number of rectangles to use and uses rectangles to estimate the area under a sine curve
     */
    public static void estimateAreaChoice() {
        System.out.print("Enter no of rectangles to use: ");
        int no = chooseInRange(1, 500);
        double area = SineCalc.estimateArea(no);
        System.out.printf("Area is %.4f\n", area);
    }

    /**
     * Asks a user for number of rectangles to use and draws a sine curve with that number of rectangles dividing
     * a sine curve
     */
    public static void drawCurveAndRecs() {
        System.out.print("Enter no of rectangles to use: ");
        int no = chooseInRange(1, 500);
        SineDraw.drawSineWave(no);
    }

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            printMenu();
            int choice = chooseInRange(0, 3);
            if (choice == 0) {
                exit = true;
            }
            if (choice == 1) {
                findYChoice();
            }
            if (choice == 2) {
                estimateAreaChoice();
            }
            if (choice == 3) {
                drawCurveAndRecs();
            }
        }
    }

}
