/**
 * Project 2: Area Under Curve: Sine Wave
 * A class for calculating areas.
 * 
 * @author      Markell Thornton
 * @version     1.0
 * @date        7/14/2023
 */
public class Areas {

    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Areas
     */
    public Areas() {
    
        // initialise instance variables
        x = 0;
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public int sampleMethod(int y) {
    
        // put your code here
        return x + y;
    }
}
