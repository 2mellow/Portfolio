/**
 * A class with sine calculation functions
 *
 * @author      Markell Thornton
 * @version     1.0
 * @date        7/14/2023
 */

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

/**
 * Provides tests for the SineCal class
 */
public class SineCalcTest {


    @Test
    @DisplayName("Find y from given x")
    void testFindY() {
        double y = SineCalc.findY(1.2);
        assertEquals(0.93203, y, 0.001);
    }

    @Test
    @DisplayName("Estimate area under a curve using rectangles")
    void testEstimateArea() {
        double area = SineCalc.estimateArea(5);
        assertEquals(2.033, area, 0.001);
    }

    @Test
    @DisplayName("Estimate area under a curve using negative no of rectangles")
    void testEstimateAreaWithNegativeNo() {
        assertThrows(IllegalArgumentException.class, () -> {
            SineCalc.estimateArea(-10);
        });
    }

}
