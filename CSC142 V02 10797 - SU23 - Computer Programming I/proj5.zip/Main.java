import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Iterator;

/**
 * Main class to test the features of MusicTrack class, output in PlayList.txt
 *
 * @author      Markell Thornton
 * @version     1.0
 */
public class Main {
    public static void main(String[] args) {
        ArrayList<MusicTrack> favTrack = new ArrayList<>();
        favTrack.add(new MusicTrack("Blinding Lights", "The Weeknd"));
        favTrack.add(new MusicTrack("Shape of You", "Ed Sheeran"));
        favTrack.add(new MusicTrack("Rolling in the Deep", "Adele"));
        favTrack.add(new MusicTrack("Old Town Road", "Lil Nas X ft. Billy Ray Cyrus"));
        favTrack.add(new MusicTrack("Uptown Funk", "Mark Ronson ft. Bruno Mars"));

        ArrayList<MusicTrack> friendsTrack = new ArrayList<>();
        friendsTrack.add(new MusicTrack("Shape of You", "Ed Sheeran"));
        friendsTrack.add(new MusicTrack("Sicko Mode", "Travis Scott"));
        friendsTrack.add(new MusicTrack("Someone Like You", "Adele"));
        friendsTrack.add(new MusicTrack("Thinking Out Loud", "Ed Sheeran"));
        friendsTrack.add(new MusicTrack("Bad Guy", "Billie Eilish"));
        friendsTrack.add(new MusicTrack("Havana", "Camila Cabello ft. Young Thug"));

        friendsTrack.remove(1);

        ArrayList<MusicTrack> partyTrack = new ArrayList<>();
        partyTrack.addAll(favTrack);
        partyTrack.addAll(friendsTrack);

        Random random = new Random();
        Iterator<MusicTrack> trackIterator = partyTrack.iterator();
        while (trackIterator.hasNext()) {
            MusicTrack currentTrack = trackIterator.next();
            int randNo = random.nextInt(0, 101);
            currentTrack.setTrackOrder(randNo);
        }

        Collections.sort(partyTrack);
        PrintStream printStream = null;
        File file = new File("PlayList.txt");
        try {
            printStream = new PrintStream(file);
        } catch (FileNotFoundException e) {
            System.out.println("Could not write playlist to file");
        }
        if (printStream != null) {
            printStream.print("""
                    --------------
                    Party Playlist
                    --------------
                    """);
            for (int i = 0; i < partyTrack.size(); i++) {
                printStream.printf("%2d. %s\n", (i + 1), partyTrack.get(i).toString());
            }
            printStream.close();
        }
    }
}
