/**
 * A class that represents a single song in an album
 * 
 * @author      Markell Thornton
 * @version     1.0
 */
public class MusicTrack implements Comparable<MusicTrack> {
    private String artist;
    private String title;
    private int trackOrder;

    MusicTrack(String artist, String title) {
        this.setArtist(artist);
        this.setTitle(title);
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        if (artist == null || artist.isEmpty()) {
            throw new IllegalArgumentException("artist can not be null or empty");
        }
        this.artist = artist;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        if (title == null || title.isEmpty()) {
            throw new IllegalArgumentException("title can not be null or empty");
        }
        this.title = title;
    }

    public int getTrackOrder() {
        return trackOrder;
    }

    public void setTrackOrder(int trackOrder) {
        this.trackOrder = trackOrder;
    }

    public int compareTo(MusicTrack track2) {
        return Integer.compare(this.trackOrder, track2.trackOrder);
    }

    public String toString() {
        return String.format("%s -- %s", title, artist);
    }

}
