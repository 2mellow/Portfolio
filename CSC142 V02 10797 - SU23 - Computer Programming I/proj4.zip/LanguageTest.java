import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;


/**
 * A class for testing Language class
 *
 * @author      Markell Thornton
 * @version     1.0
 */
public class LanguageTest {

    Language lang;

    @BeforeEach
    public void beforeEach() {
        lang = new Language("C", "c.txt", Language.Type.COMPILED);
    }

    @Test
    public void testConstructor() {
        Language lang2 = new Language("b", "b.txt", Language.Type.COMPILED);
        assertEquals(lang2.getName(), "b");
        assertEquals(lang2.getFilename(), "b.txt");
    }

    @Test
    public void testConstructorWithNullName() {
        assertThrows(IllegalArgumentException.class, () -> {
            Language lang2 = new Language(null, "b.txt", Language.Type.COMPILED);
        });
    }

    @Test
    public void testConstructorWithEmptyFilename() {
        assertThrows(IllegalArgumentException.class, () -> {
            Language lang2 = new Language("b", "", Language.Type.COMPILED);
        });
    }

    @Test
    public void testConstructorWithNullType() {
        assertThrows(IllegalArgumentException.class, () -> {
            Language lang2 = new Language("b", "b.txt", null);
        });
    }

    @Test
    public void testGetName() {
        assertEquals(lang.getName(), "C");
    }

    @Test
    public void getFilename() {
        assertEquals(lang.getFilename(), "c.txt");
    }

    @Test
    public void testGetType() {
        assertEquals(lang.getType(), Language.Type.COMPILED);
    }

    @Test
    public void testGetKwdCount() {
        assertEquals(lang.getKwdCount(), 33);
    }

    @Test
    public void testGetKwd() {
        assertEquals(lang.getKwd(4), "char");
    }

    @Test
    public void testGetKwdAtNegativePos() {
        assertNull(lang.getKwd(-4));
    }

    @Test
    public void testGetKwdAtIndexGreaterThanLength() {
        assertNull(lang.getKwd(50));
    }

    @Test
    public void testFindKwd() {
        assertEquals(lang.findKwd("for"), 14);
    }

    @Test
    public void testFindShortestKwd() {
        assertEquals(lang.findShortestKwdLength(), 2);
    }

    @Test
    public void testFindLongestKwd() {
        assertEquals(lang.findLongestKwdLength(), 8);
    }

    @Test
    public void testToString() {
        assertEquals(lang.toString(), "Language C of type COMPILED keyword count : 33");
    }

}
