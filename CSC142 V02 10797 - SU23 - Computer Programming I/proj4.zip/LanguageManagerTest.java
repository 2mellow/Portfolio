import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.FileNotFoundException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;


/**
 *A class for testing Language Manager class
 *
 * @author      Markell Thornton
 * @version     1.0
 */
public class LanguageManagerTest {
    LanguageManager manager;

    @BeforeEach
    public void beforeEach() throws FileNotFoundException {
        File langSmallFile = new File("languages_small.txt");
        manager = new LanguageManager(langSmallFile);
    }

    @Test
    public void testConstructor() throws FileNotFoundException {
        LanguageManager manager1 = new LanguageManager(new File("languages_small.txt"));
        assertEquals(manager1.getLanguageCount(), 2);
    }

    @Test
    public void testConstructorWithMissingFile() {
        assertThrows(FileNotFoundException.class, () -> {
            LanguageManager manager1 = new LanguageManager(new File("missing.txt"));
        });
    }


    @Test
    public void testGetLangCount() {
        assertEquals(manager.getLanguageCount(), 2);
    }

    @Test
    public void testGetLang() {
        assertEquals(manager.getLanguage(1).getName(), "Python");
    }

    @Test
    public void testGetLangWithNegativeIndex() {
        assertNull(manager.getLanguage(-3));
    }

    @Test
    public void testGetLangWithLargeIndex() {
        assertNull(manager.getLanguage(3));
    }

    @Test
    public void testFindShortestKwdLength() {
        assertEquals(manager.findShortestKwdLength(), 2);
    }

    @Test
    public void testFindLongestKwdLength() {
        assertEquals(manager.findLongestKwdLength(), 8);
    }

    @Test
    public void testFindLangWithMostKwds() {
        assertEquals(manager.findLangWithMostKwds(), 0);
    }

    @Test
    public void testFindLangWithFewestKwds() {
        assertEquals(manager.findLangWithFewestKwds(), 1);
    }

    @Test
    public void testFindLangKeywordMatches() {
        assertArrayEquals(manager.findLangKwdMatches("for"), new int[]{0, 1});
    }

    @Test
    public void testFindLangKeywordMatchesWithNullKeyword() {
        assertThrows(IllegalArgumentException.class, () -> {
            manager.findLangKwdMatches(null);
        });
    }

    @Test
    public void testFindLangOfType() {
        assertArrayEquals(manager.findLangsOfType(Language.Type.INTERPRETED), new int[]{1});
    }

}
