import java.io.File;
import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        File languageFile = new File("languages.txt");
        LanguageManager manager = new LanguageManager(languageFile);
        int a = 0;

        String info = """
                Found languages count       : %d
                Shortest keyword length     : %d
                Longest keyword length      : %d
                Lang with most keywords     : %s
                Lang with fewest keywords   : %s
                Sample languages and keywords:
                """;
        System.out.printf(info,
                manager.getLanguageCount(),
                manager.findShortestKwdLength(),
                manager.findLongestKwdLength(),
                manager.findLangWithMostKwds(),
                manager.findLangWithFewestKwds()
        );
        // Print the first 5 languages with keywords, also print there first 5 keywords
        int count = 0;
        int index = 0;
        while (count < 5 && count < manager.getLanguageCount()) {
            Language lang = manager.getLanguage(index);
            if (lang.getKwdCount() > 0) {
                System.out.println(lang);
                for (int i = 0; i < 5 && i < lang.getKwdCount(); i++) {
                    System.out.println("  " + lang.getKwd(i));
                }
                count++;
            }
            index++;
        }
    }
}
