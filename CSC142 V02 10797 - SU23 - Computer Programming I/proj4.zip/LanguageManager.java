import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * A class that manages Languages, provides methods to get info from them
 *
 * @author      Markell Thornton
 * @version     1.0
 */
public class LanguageManager implements LanguageManagerInterface {
    private Language[] languages;

    LanguageManager(File languageFile) throws FileNotFoundException {
        if (languageFile == null) {
            throw new IllegalArgumentException("language file can not be null");
        }
        Scanner scanner = new Scanner(languageFile);
        int count = scanner.nextInt();
        languages = new Language[count];
        // clear newline
        scanner.nextLine();
        //ignore header line
        scanner.nextLine();
        for (int i = 0; i < count; i++) {
            String line = scanner.nextLine();
            String[] tokens = line.split(",");
            String name = tokens[0];
            String filename = tokens[1];
            Language.Type type = null;
            String strType = tokens[2];
            if (strType.equalsIgnoreCase("Compiled")) {
                type = Language.Type.COMPILED;
            }
            if (strType.equalsIgnoreCase("Interpreted")) {
                type = Language.Type.INTERPRETED;
            }
            if (strType.equalsIgnoreCase("Scripting")) {
                type = Language.Type.SCRIPTING;
            }
            if (strType.equalsIgnoreCase("Numerical_Analysis")) {
                type = Language.Type.NUMERICAL_ANALYSIS;
            }
            languages[i] = new Language(name, filename, type);
        }
        sortLangs();
    }

    public int getLanguageCount() {
        return languages.length;
    }

    public Language getLanguage(int index) {
        if (index < 0 || index >= languages.length) {
            return null;
        }
        return languages[index];
    }

    public int findShortestKwdLength() {
        int length = -1;
        for (int i = 0; i < languages.length; i++) {
            Language lang = languages[i];
            // only consider languages with keywords
            if (lang.getKwdCount() > 0) {
                if (lang.findShortestKwdLength() < length || length == -1) {
                    length = lang.findShortestKwdLength();
                }
            }
        }
        return length;
    }

    public int findLongestKwdLength() {
        int length = -1;
        for (int i = 0; i < languages.length; i++) {
            Language lang = languages[i];
            if (lang.findLongestKwdLength() > length || length == -1) {
                length = lang.findLongestKwdLength();
            }
        }
        return length;
    }

    public int findLangWithFewestKwds() {
        int count = -1;
        int langIndex = -1;
        for (int i = 0; i < languages.length; i++) {
            Language lang = languages[i];
            if (lang.getKwdCount() < count || count == -1) {
                count = lang.getKwdCount();
                langIndex = i;
            }
        }
        return langIndex;
    }

    public int findLangWithMostKwds() {
        int count = -1;
        int langIndex = -1;
        for (int i = 0; i < languages.length; i++) {
            Language lang = languages[i];
            if (lang.getKwdCount() > count || count == -1) {
                count = lang.getKwdCount();
                langIndex = i;
            }
        }
        return langIndex;
    }

    public int[] findLangKwdMatches(String keyword) {
        if (keyword == null) {
            throw new IllegalArgumentException("search keyword can not be null");
        }
        int count = languages.length;
        int[] found = new int[count];
        int foundCount = 0;
        for (int i = 0; i < count; i++) {
            Language lang = languages[i];
            boolean matches = false;
            for (int j = 0; j < lang.getKwdCount(); j++) {
                if (lang.getKwd(j).equals(keyword)) {
                    matches = true;
                }
            }
            if (matches) {
                found[foundCount] = i;
                foundCount++;
            }
        }
        int[] onlyFoundLangs = new int[foundCount];
        for (int i = 0; i < foundCount; i++) {
            onlyFoundLangs[i] = found[i];
        }
        return onlyFoundLangs;
    }

    public int[] findLangsOfType(Language.Type type) {
        int[] langs = new int[languages.length];
        int foundCount = 0;
        for (int i = 0; i < languages.length; i++) {
            if (languages[i].getType() == type) {
                langs[foundCount] = i;
                foundCount++;
            }
        }
        int[] onlyFoundLangs = new int[foundCount];
        for (int i = 0; i < foundCount; i++) {
            onlyFoundLangs[i] = langs[i];
        }
        return onlyFoundLangs;
    }

    public void sortLangs() {
        for (int pass = 1; pass < languages.length; pass++) {
            Language temp = languages[pass];
            int checkPos = pass - 1;
            while (checkPos >= 0 && temp.getName().compareTo(languages[checkPos].getName()) < 0) {
                languages[checkPos + 1] = languages[checkPos];
                checkPos--;
            }
            languages[checkPos + 1] = temp;
        }
    }
}

