import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


/**
 * A class that represent a programming language, holds name,type and keywords
 *
 * @author      Markell Thornton
 * @version     1.0
 */
public class Language implements LanguageInterface {

    private String name;
    private String filename;
    private Type type;
    private String[] keywords;

    /**
     * Creates a Language from name, keyword file and type parameters
     *
     * PRECONDITIONS:
     * - name and filename mst not be null or empty
     * - type must not be null
     *
     * @param name langauge name
     * @param filename keywords filename
     * @param type language type
     */
    Language(String name, String filename, Type type) {
        if (name == null||name.isEmpty()) {
            throw new IllegalArgumentException("name can not be null");
        }
        if (filename == null||filename.isEmpty()) {
            throw new IllegalArgumentException("language filename can not be null");
        }
        if (type == null) {
            throw new IllegalArgumentException("language type can not be null");
        }

        this.name = name;
        this.type = type;
        this.filename = filename;
        File file = new File(filename);
        try {
            Scanner fileScanner = new Scanner(file);
            int count = fileScanner.nextInt();
            keywords = new String[count];
            for (int i = 0; i < count; i++) {
                String keyword = fileScanner.next();
                keywords[i] = keyword;
            }
        } catch (FileNotFoundException e) {
            keywords = new String[0];
        }
        sortKwds();
    }

    /**
     * Gets  language's name
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the langauge's keyword filename
     * @return filename
     */
    public String getFilename() {
        return filename;
    }

    /**
     * Gets the langauge's type
     *
     * @return type
     */
    public Type getType() {
        return type;
    }

    /**
     * Get no fo keywords in this language
     * @return count of keywords
     */
    public int getKwdCount() {
        return keywords.length;
    }

    /**
     * Gets keyword at an index
     *
     * PRECONDITIONS:
     * - index must be between 0 and keywords array length
     *
     * @param index index to get from
     * @return the keyword
     */
    public String getKwd(int index) {
        if (index < 0 || index >= keywords.length) {
            return null;
        }
        return keywords[index];
    }

    /**
     * Find position of a keyword
     * @param keyword the keyword to search for
     * @return index of keyword or -1 if keyword is missing
     */
    public int findKwd(String keyword) {
        int index = -1;
        for (int i = 0; i < keywords.length; i++) {
            if (keywords[i].equals(keyword)) {
                index = i;
            }
        }
        return index;
    }

    /**
     * finds the length of the shortest keyword
     * @return the length or -1 if no keyword exists
     */
    public int findShortestKwdLength() {
        int length = -1;
        for (int i = 0; i < keywords.length; i++) {
            String keyword = keywords[i];
            if (keyword.length() < length || length == -1) {
                length = keyword.length();
            }
        }
        return length;
    }

    /**
     * finds the length of the longest keyword
     * @return the length or -1 if no keyword exists
     */
    public int findLongestKwdLength() {
        int length = -1;
        for (int i = 0; i < keywords.length; i++) {
            String keyword = keywords[i];
            if (keyword.length() > length || length == -1) {
                length = keyword.length();
            }
        }
        return length;
    }

    /**
     * Sorts the keywords alphabetically
     */
    public void sortKwds() {
        for (int pass = 1; pass < keywords.length; pass++) {
            String temp = keywords[pass];
            int checkPos = pass - 1;
            while (checkPos >= 0 && temp.compareTo(keywords[checkPos]) < 0) {
                keywords[checkPos + 1] = keywords[checkPos];
                checkPos--;
            }
            keywords[checkPos + 1] = temp;
        }
    }

    /**
     * Returns a string representation for a language, with name, type and keyword count
     * @return the string representation
     */
    public String toString() {
        return String.format("Language %s of type %s keyword count : %d", name, type, getKwdCount());
    }

}
